Guideline to run this tool , 
You just need to run the index.html file

You will get to select model name from dropdown.
Hit choose model.Create query will be created for selected model.
you can edit query if you want.
In the textbox below it, you will have to specify number of records you want to create.
At the bottom of the page send button is there.Which will execute create query,and data will be 
populated in the database.


Note : Creating number of records feature is not working. But you can modify query to create one record.
 
Working on download feature,to download created query.